import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { KhqrModule } from 'src/mod/khrq.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TokenModule } from './mod/token.module';
import { UserToken } from 'src/entity/user-token.entity';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'ep-yellow-recipe-a5rj9c27.us-east-2.aws.neon.tech',
      port: 5432,
      username: 'chhean1122_owner',
      password: '7kxXaEeCgcZ9',
      database: 'chhean1122',
      ssl: true, 
      extra: {
        ssl: {
          rejectUnauthorized: true, 
        },
      },
      synchronize: true, 
      entities: [
        UserToken,
      ],
    }),
    KhqrModule,
    TokenModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
